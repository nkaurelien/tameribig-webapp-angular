import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ecommerce-section',
  templateUrl: './ecommerce-section.component.html',
  styleUrls: ['./ecommerce-section.component.scss']
})
export class EcommerceSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
