import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-magazine-section',
  templateUrl: './magazine-section.component.html',
  styleUrls: ['./magazine-section.component.scss']
})
export class MagazineSectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
