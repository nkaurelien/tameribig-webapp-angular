import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flipping-cards',
  templateUrl: './flipping-cards.component.html',
  styleUrls: ['./flipping-cards.component.scss']
})
export class FlippingCardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
