import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-easy',
  templateUrl: './easy.component.html',
  styleUrls: ['./easy.component.scss']
})
export class EasyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
