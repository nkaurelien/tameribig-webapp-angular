
import { Component} from '@angular/core';

@Component({
  selector: 'app-intros-section',
  templateUrl: './intros-section.component.html',
  styleUrls: ['./intros-section.component.scss']
})
export class IntrosSectionComponent {


  

}
