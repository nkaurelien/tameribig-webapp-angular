import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-switch',
  templateUrl: './switch.component.html',
  styleUrls: ['./switch.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SwitchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
