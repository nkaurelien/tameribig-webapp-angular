import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-modal-styles',
  templateUrl: './modal-styles.component.html',
  styleUrls: ['./modal-styles.component.scss']
})
export class ModalStylesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
